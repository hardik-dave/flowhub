# FlowOS Hub — Claude Code Kickoff Brief

Paste this as your first message in the Hub's terminal session. It
orients you; the authoritative detail is in SPEC.md and AGENTS.md at
the repo root — read both IN FULL before writing code. If anything here
conflicts with SPEC.md, SPEC.md wins.

## What you're building

The FlowOS Hub: a standalone multi-tenant licensing, user, and
subscription backend serving multiple desktop products. Independent
project — NO shared code with any product repo. Go + PostgreSQL backend
plus a small React admin dashboard.

Products served (seed all as `products` rows): Option Analyzer (live
first), FlowOS (in progress), and room for at least four total. Which
tenant may sell which product is the `tenant_products` join. Nothing
may hardcode a single product code.

## Scale posture (updated — build for this, not more)

20-25 tenants, multiple products each, low-thousands of users total,
a few verify/login calls per second at peak (market open). Single
server, single Postgres, modular monolith. This is a small CRUD system
with high correctness stakes, NOT a scale problem. Because it's 20-25
real paying tenants (not a pilot), do these from the start rather than
later: proper DB connection pooling, an index on the hot login/verify
path, and backups you have actually test-restored once.

Banned (SPEC.md 1): microservices, queues, Kubernetes, ORM, GraphQL,
payment-gateway processing in v1 (payments recorded manually; schema is
gateway-ready).

## The login model (important — primary path is password, not key)

Users log in with **email/username + password**. The desktop products
call `POST /api/v1/app/login`, the Hub authenticates the password and
returns the license/entitlement status in the same response. The
license KEY still exists as the internal entitlement record (support,
CSV import, activation) but is NEVER a credential the user types. One
user, one password, works across every product they're licensed for —
that single-login experience is a hard product requirement (customers
are traders, not sysadmins). This needs NO SSO machinery: it's just the
same `users` row checked at each product's login, with per-product
`licenses`. Do not build an identity provider / OAuth / SSO in v1 — the
Hub is the licensing + subscription authority, not the login provider
for third-party apps. The product-agnostic user model preserves the
option to add real SSO deliberately later.

## The two contracts that must not drift

Both are consumed by shipped/near-shipped desktop clients. Field names,
the status strings (`valid` / `paused` / `revoked` / `not_found`), and
reason-template style are LAW — only ADD optional fields, never rename
or restructure.

- `POST /api/v1/app/login` — `{tenant_slug, username_or_email,
  password, product_code}` -> authenticates, returns
  `{status, reason, warning, session_token, user, entitlements,
  subscription}`. This is the primary desktop path.
- `POST /api/v1/app/verify` (SPEC.md 6.1) — the underlying entitlement
  check the login response embeds. Keep it as the golden internal
  contract; login wraps it with authentication.

`not_found` deliberately also covers wrong-password/unknown-user (same
message, so usernames can't be probed).

## Stack (locked, SPEC.md 1 — do not substitute)

Go 1.22+ with chi + pgx (no ORM), golang-migrate, argon2id for password
AND license-key hashing, PostgreSQL 16, React + Vite + TypeScript for
the dashboard, Caddy for TLS.

## Already in the repo (scaffold — build on it, don't recreate)

The initial migration (10 tables, generated from SPEC.md 3), a tested
`add_working_days` grace function, the Crockford-base32 license keygen,
and a stdlib route skeleton where every endpoint 501s with its spec
section. The route list IS the API surface — implement those, add none.

## TOMORROW's deliverable (deadline — do this first)

Option Analyzer demos to a client tomorrow and needs a working login
endpoint TODAY. Build `POST /api/v1/app/login` for real, backed by a
tiny SEEDED data source (a couple of hardcoded users/licenses, or the
real tables with seed rows) — NOT an always-return-valid stub. Same
endpoint, same response shape; when Postgres is wired for real, only
the data source changes, the contract doesn't. This is the "fake data,
real endpoint" principle: nothing on the client changes between demo
and production. Seed at least one Option Analyzer user that returns
`status: valid`, plus (for testing the unhappy paths) one that returns
`paused` and one unknown that returns `not_found`.

Then proceed through the milestones:

## Milestone order (SPEC.md 10 — STOP after each for me to test)

- M-A: schema + auth — migrations apply clean; register -> OTP (console
  sender) -> login round-trips; argon2id verified; products + house
  tenant seeded.
- M-B: the login/verify golden contract — one table-driven test per row
  of the 4 access-rule mapping table, exact status strings; working-days
  grace tested against golden dates; the tomorrow-seed path folded into
  real DB reads.
- M-C: tenant-admin dashboard — user list/detail, status change (with
  mandatory reason), payment entry, license grant/regenerate, audit
  trail.
- M-D: CSV user import, rate limits, deploy scripts (Caddyfile, systemd,
  backup cron).

## Non-negotiable rules (AGENTS.md)

Money is integer paise, never float. Every query tenant-scoped. Every
status/subscription/license/payment mutation writes an audit_log row in
the same transaction. OTP codes and passwords and license keys NEVER in
logs. Tests ship in the same commit; run `go vet && go test ./...` and
paste the REAL output before claiming done. Never modify a failing test
to pass. When the spec is silent, pick the simplest option and record it
in DECISIONS.md.

## One human task no code can unblock

TRAI DLT registration for SMS OTP (SPEC.md 6.4) — sender ID + template
approval via an SMS provider, days-to-weeks of paperwork. Flag it to me
now; use the console OTP sender for dev meanwhile.

Start by reading SPEC.md and AGENTS.md, then confirm the login/verify
contract and the tomorrow-deliverable plan before writing code.
