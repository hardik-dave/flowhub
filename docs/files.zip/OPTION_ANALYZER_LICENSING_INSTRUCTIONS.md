# Option Analyzer — Licensing Integration Instructions

For the Option Analyzer desktop developer. Build exactly to this. The
key property: **what you build for tomorrow's demo is the same code
that runs in production** — the only thing that changes at deploy is a
config URL, never the client code.

## The idea in one line

The user logs in once with **email/username + password**. Option
Analyzer does NOT manage users, passwords, or licenses itself — it
sends the login to a central service ("the Hub"), which authenticates
the user and returns whether they're allowed into this product. The
user NEVER types a license key; that's an internal record the Hub
holds, not something a human should memorize.

## What to build: one login call at startup

Before the main UI loads, show a simple login box and call:

```
POST <HUB_URL>/api/v1/app/login
Content-Type: application/json

{
  "tenant_slug": "<tenant>",
  "username_or_email": "<what the user typed>",
  "password": "<what the user typed>",
  "product_code": "option_analyzer"
}
```

The response is ALWAYS this shape (whether backed by seed data tomorrow
or the real database in production):

```json
{
  "status": "valid",
  "reason": "",
  "warning": "",
  "session_token": "...",
  "user": { "username": "...", "first_name": "..." },
  "entitlements": { "tier": "RETAIL" },
  "subscription": { "valid_until": "2026-12-31" }
}
```

`status` is one of: `valid` / `paused` / `revoked` / `not_found`.
(`not_found` also covers wrong password / unknown user — the message
is deliberately identical so it can't be used to probe which usernames
exist.)

## The rules (this IS the whole contract — nothing here changes later)

1. **Switch on `status`, nothing else.**
   - `valid` -> allow the user into the app. Keep the `session_token`
     for the session.
   - `paused` / `revoked` / `not_found` -> block entry and show the
     `reason` string verbatim (it is written to be shown to the user —
     do not rewrite it into a generic message).
   - `warning` non-empty (grace period) -> allow entry, but surface the
     warning text.

2. **HUB_URL lives in config, never hardcoded.** Tomorrow it points at
   the temporary service; at deploy it points at the real Hub. That one
   config value is the ONLY difference between demo and production. The
   code is identical.

3. **Fail closed, with a 72-hour offline grace.** If the Hub is
   unreachable:
   - If this user logged in successfully within the last 72 hours ->
     allow entry (offline grace). Cache the last-successful-login
     timestamp locally, per user.
   - If they have never logged in successfully on this machine -> block,
     with a clear "cannot reach licensing server" message.
   Unreachable is NOT invalid — never treat a network failure as
   `revoked`.

4. **Send `product_code: "option_analyzer"` as a constant.** This is
   what lets one Hub serve every product, and lets the SAME email +
   password work across all of them (Option Analyzer, FlowOS, and
   others). One login the customer remembers — they're traders, not
   sysadmins.

5. **Do NOT build any of this yourself:** no local user table, no
   password storage, no license-key handling, no subscription/expiry
   logic, no "activate" flow. The Hub owns all of it. Your entire job
   is: collect email + password, call login, obey the status. Anything
   more will have to be torn out when the real Hub arrives.

## The login box

Three fields, and keep it that simple:
- **Email or username**
- **Password**
- **Tenant** — for a direct retail customer, DEFAULT this to a fixed
  value in config so the user doesn't see it. Only broker-partner
  customers with their own tenant would ever need to enter it, and even
  then it can be pre-filled per build.

No "register", no "forgot password", no "activate license" in the
desktop app for now — those live in the Hub's web side, not here. (If
the client asks for in-app registration later, it's another Hub
endpoint, same pattern — not your local code.)

## What you get for free by doing exactly this

When the real Hub goes live, this same client build — unchanged except
for the HUB_URL config — works against real users, real recorded
payments, real subscription expiry and grace periods, and the same
email+password logging the user into every product on the Hub. You
will not revisit this integration.

## What NOT to do (the tempting deadline shortcuts)

- Do NOT hardcode "always valid" in the client. If tomorrow's demo
  must always pass, that belongs in the SERVICE's seed data
  (swappable server-side), never in the desktop app (which would have
  to be changed and re-shipped to disable it).
- Do NOT hardcode the Hub URL "just for now."
- Do NOT store the password locally or build a local login fallback.
  Fail closed per rule 3, caching only a success TIMESTAMP, never the
  password.

If you follow the five rules, tomorrow's demo and next quarter's
production run the identical client build.
